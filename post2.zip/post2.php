<?php include 'inc/header.php'; ?>
<div class="container">
	<div class="contentsection contemplete clear">
        <!-- profile image -->
        <?php 	
        global $pro_image;			
			$query = "SELECT * FROM user2 WHERE user_name='".$_SESSION['username']."'";
				$result = $db->select($query);
                if($result != false){
                    if(mysqli_num_rows($result)>0){
		?>								

        <?php  
            while ($user = mysqli_fetch_array($result)) {
                $pro_image= $user['image']; ?>												
            <img src="<?php echo $user['image'];?> " style="width:50px;height: 50px;margin:2px; border-radius:60%;" />			
        <?php }}}?>
         <!-- profile image -->

          <div class="box round first grid">
                
                <?php
                    if ($_SERVER['REQUEST_METHOD'] == 'POST')
                    {
                        $body   = mysqli_real_escape_string($db->link, $_POST['body']);
                        $author = mysqli_real_escape_string($db->link, $_SESSION['username']);
                        $pro_image = mysqli_real_escape_string($db->link, $pro_image);

                        if($body == ""|| $author == ""){
                            echo "<span class= 'error'>Field must not be empty !</span>";
                        }

   
                       else
                        {
                           $query = "INSERT INTO tbl_post( body, author, pro_image) VALUES('$body', '$author',
                           '$pro_image')";
    
                           $inserted_rows = $db->insert($query);
                           if ($inserted_rows) 
                           {
                            echo "<span class='success'>Post Inserted Successfully.</span>";
                           }else 
                           {
                            echo "<span class='error'>Post Not Inserted !</span>";
                           }
                        }
                    }   
                ?>
                    <div class="block-post">               
                     <form action="" method="post" enctype="multipart/form-data">
                        <table class="addpost-form">
    
                            <h2>Add New Post</h2>
                            
                            <tr>
                                <td style="vertical-align: top; padding-top: 9px;">
                                    <label>Content</label>
                                </td>
                                <td>
                                    <textarea id="myEditor" name="body"> </textarea>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <input type="text" hidden name= "author"  class="medium" />
                                </td>
                            </tr>
                           
                            <tr>
                                <td></td>
                                <td>
                                    <input type="submit" name="submit" Value="Save" />
                                </td>
                            </tr>
                        </table>
                        </form>
                    </div>
                </div>
                <!-- add post -->

	<div class="post-section contemplete clear">
       
            
		<div class="post-main clear">
		    <!--pagination-->
            <?php
                $per_page = 10;
                if (isset($_GET["page"])){
                    $page = $_GET["page"];
                }
                else{
                    $page=1;
                }
                $start_from = ($page-1)*$per_page;
            ?>
            <!--pagination-->
            <?php	
                $query = "select * from tbl_post where active=1 order by id desc limit $start_from, $per_page";
                $post= $db->select($query);
                if($post){
                while ($result = $post->fetch_assoc()){
            ?>

            
			<div class="post clear> 
                <a href="#"><img  style="width:40px;height: 40px;margin:1px; border-radius:60%;"  src="<?php echo $result['pro_image']?>">
                <?php echo $result['author'];?><br> <br></a>
                <?php echo $fm->formatDate($result['date']);?>
                <p>
					<?php echo $result['body']; ?>
                </p> <br/>
                
			</div>
    <?php } ?> <!-- end while loop -->

    

<!--pagination-->
<?php 
	$query = "select * from tbl_post";
	$result = $db->select($query);
	$total_rows = mysqli_num_rows($result);
	$total_pages = ceil($total_rows/$per_page);			

	echo "<span class='pagination'><a href='post2.php?page=1'>".'First Page'."</a>"; 

	for($i=1; $i<=$total_pages; $i++){
		echo "<a href='post2.php?page=".$i."'>$i</a>";
	}

	echo "<a href='post2.php?page=$total_pages'>".'Last Page'."</a></span>"
?>

</div>
<!--pagination-->
        <?php } else { header("Location:404.php");} ?>	

		

		</div>
        </div>
<?php include 'inc/footer.php'; ?>